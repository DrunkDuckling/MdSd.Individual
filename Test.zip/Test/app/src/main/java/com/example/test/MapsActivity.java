package com.example.test;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    private String[] placeNames;
    private String[] imageUrl;
    List<Place> findPlaces;

    protected LocationManager locationManager;
    protected LocationListener locationListener;


    // DSL Params
    double distanceThreshold = 500; //m
    String filterQuery = "restaurant";
    Location startPoint = new Location("locationA"); // Used for distance measuring
    Location endPoint = new Location("locationB"); // Used for distance measuring


    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        if (!Permissions.Check_FINE_LOCATION(MapsActivity.this)) {
            Permissions.Request_FINE_LOCATION(MapsActivity.this, 1234);
        } else {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10, this);
        }



    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style));
        mMap.setMyLocationEnabled(true);

    }


    class GetPlacesAsyncTask extends AsyncTask<Void, Void, Void> {
        //private ProgressDialog bar;
        private Context context;
        private Location location;

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            mMap.clear();

            for (int i = 0; i < findPlaces.size(); i++) {
                if (findPlaces.get(i) != null) {
                    Place placeDetail = findPlaces.get(i);
                    endPoint.setLatitude(placeDetail.getLatitude());
                    endPoint.setLongitude(placeDetail.getLongitude());

                    if (location.distanceTo(endPoint) < distanceThreshold) {
                        LatLng place = new LatLng(findPlaces.get(i).getLatitude(), findPlaces.get(i).getLongitude());
                        MarkerOptions marker = new MarkerOptions().position(place).title(findPlaces.get(i).getName());
                        marker.icon(BitmapDescriptorFactory.fromBitmap(placeDetail.getBitmap()));

                        mMap.addMarker(marker);
                    }
                }
            }
        }

        public GetPlacesAsyncTask(Context context, Location location) {
            this.context = context;
            this.location = location;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //bar = new ProgressDialog(context);
            //bar.setIndeterminate(true);
            //bar.setTitle("Loading Places");
            //bar.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            findNearLocation(location);
            return null;
        }
    }

    public void findNearLocation(Location location)   {
        PlacesService service = new PlacesService(getResources().getString(R.string.google_maps_key));
        findPlaces = service.findPlaces(location.getLatitude(), location.getLongitude(), filterQuery, distanceThreshold);

        placeNames = new String[findPlaces.size()];
        imageUrl = new String[findPlaces.size()];

        for (int i = 0; i < findPlaces.size(); i++) {
            if (findPlaces.get(i) != null) {
                Place placeDetail = findPlaces.get(i);
                endPoint.setLatitude(placeDetail.getLatitude());
                endPoint.setLongitude(placeDetail.getLongitude());

                if (startPoint.distanceTo(endPoint) < distanceThreshold) {
                    System.out.println(placeDetail.getName());
                    placeNames[i] = placeDetail.getName();
                    imageUrl[i] = placeDetail.getName();
                }
            }
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 14));
        new GetPlacesAsyncTask(this, location).execute();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

}
